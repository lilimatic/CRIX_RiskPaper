import numpy as np
import pandas as pd
import datetime
import os

from scipy.integrate import quad
from scipy.optimize import least_squares


def heston_cf(u, t, ps):

    alpha = (- u ** 2 - 1j * u) / 2
    beta = ps['LAMBDA'] - ps['RHO'] * ps['XI'] * 1j * u
    gamma = ps['XI'] ** 2 / 2

    d = np.sqrt(beta ** 2 - 4 * alpha * gamma)

    r_pos = (beta + d) / 2 / gamma
    r_neg = (beta - d) / 2 / gamma
    g = r_neg / r_pos

    def C(t):
        return r_neg * t - 2 / ps['XI'] ** 2 * np.log((1 - g * np.exp(-d * t)) / (1 - g))

    def D(t):
        return r_neg * (1 - np.exp(-d * t)) / (1 - g * np.exp(-d * t))

    return np.exp(ps['VBAR'] * ps['LAMBDA'] * C(t) +
                  ps['V0'] * D(t) +
                  1j * u * (np.log(ps['SPOT']) + ps['RATE'] * t))


# e.g. Carr Madan 1999
def fourier_call(strike, ttm, cf, ps):

    def int1(u): return (np.exp(-1j * u * np.log(strike)) * cf(u - 1j, ttm, ps) / 1j / u / cf(-1j, ttm, ps)).real
    def int2(u): return (np.exp(-1j * u * np.log(strike)) * cf(u, ttm, ps) / 1j / u).real

    p1 = 1/2 + 1/np.pi * quad(int1, 0, np.inf)[0]
    p2 = 1/2 + 1/np.pi * quad(int2, 0, np.inf)[0]

    return ps['SPOT'] * p1 - strike * np.exp(- ps['RATE'] * ttm) * p2


def heston_fourier_call(ttm, strike, ps):
    return fourier_call(strike, ttm, heston_cf, ps)


def heston_calibrate_leastsquares(market_data):

    SPOT = 10000
    RATE = 0

    def call(x):
        
        LAMBDA, VBAR, RHO, XI, V0 = x
        ps = {'LAMBDA': LAMBDA, 'VBAR': VBAR, 'RHO': RHO, 'XI': XI, 'V0': V0, 'SPOT': SPOT, 'RATE': RATE}
        
        # pick first 6 instruments for calibration
        values = market_data.values[0:6]
        
        n = len(values)
        return np.sqrt(np.sum([(heston_fourier_call(ttm, strike, ps) - price * SPOT) ** 2 for strike, price, ttm in values]) / n)

    x0 = np.array([1, 0.3, -0.4, 0.7, 0.3])
    bnds = (0, 0, -1, 0, 0), (np.inf, np.inf, 1, np.inf, np.inf)

    return least_squares(call, x0, bounds=bnds, verbose=2)


def obtain_market_data(date):

    fname = os.path.join(f"{date}.csv")

    df = pd.read_csv(fname)
    df = df[df['type'] == 'C'][['maturity', 'strike', 'mark_price']]

    def ttm(maturity):
        today = datetime.datetime.strptime(date, '%Y%m%d')
        maturity = datetime.datetime.strptime(maturity, '%d%b%y')

        assert maturity > today

        # depends on the day count conventions
        return (maturity - today).days / 365.25

    df['ttm'] = df['maturity'].apply(ttm)
    df = df.rename(columns={'mark_price': 'price'})

    return df.drop(columns=['maturity'])


market_data = obtain_market_data('20200212')

output = heston_calibrate_leastsquares(market_data)
print(output)

with open("_output/calibration.txt", "w") as fp:
    fp.write(str(output))
